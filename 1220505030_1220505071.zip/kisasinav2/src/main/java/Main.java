//Alper Aziz Paksoy 1220505030
//Mehmet Yigit Erdem 1220505071



public class Main {
    public static void main(String[] args) {
        //Bina
        Bina Paksoy = new Bina("Istanbul",3,"Paksoy");
        Bina Erdem= new Bina("Istanbul",3,"Erdem");
        Bina Paksoy2 = new Bina("Trabzon",1,"Paksoy");

        // Daire nesnelerinin oluşturulması
        Daire p_daire1 = new Daire("Istanbul",1,1);
        Daire p_daire2 = new Daire("Istanbul",2,2);
        Daire p_daire3 = new Daire("Istanbul",3,3);

        Daire e_daire1 = new Daire("Istanbul",1,4);
        Daire e_daire2 = new Daire("Istanbul",2,5);
        Daire e_daire3 = new Daire("Istanbul",3,6);

        Daire p_t_daire1 = new Daire("Trabzon",1,7);

        //Ev Sahibi Olusturma
        evSahibi Alper = new evSahibi("Alper Aziz Paksoy","Istanbul",Paksoy);
        evSahibi Mehmet= new evSahibi("Mehmet Yigit Erdem","Istanbul",Erdem);

        //Kiraci Olusturma
        Kiraci yigit = new Kiraci("Yigit Ulusoy","Istanbul",Alper);
        Kiraci jale = new Kiraci("Jale de Jale","Istabul",Mehmet);
        Kiraci merve = new Kiraci("Merve Lerde","Istanbul",Mehmet);
        Kiraci ilsu = new Kiraci("Ilsu Coban","Trabzon",Alper);


       



    }
}