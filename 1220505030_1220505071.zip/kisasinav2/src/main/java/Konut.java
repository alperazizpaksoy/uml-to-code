class Konut {
    String address;

    public Konut(String address) {
        this.address = address;
    }

    public void displayInfo() {
        System.out.println("Adres: " + address);
    }
}