class Daire extends Konut implements Comparable<Daire> {
    private int apartmentNumber;
    int numberOfFloor;

    public Daire(String address, int numberOfFloor,int apartmentNumber) {
        super(address);
        this.apartmentNumber = apartmentNumber;
        this.numberOfFloor=numberOfFloor;
    }

    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.println("Daire Numarası: " + apartmentNumber);
        System.out.println("Dairenin kati : "+numberOfFloor);
        System.out.println("Bu bir dairedir.");
    }

    @Override
    public int compareTo(Daire o) {
        return Integer.compare(this.apartmentNumber, o.apartmentNumber);
    }
}