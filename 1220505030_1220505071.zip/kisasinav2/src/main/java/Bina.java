class Bina extends Konut {
    private int numberOfFloors;
    String name;

    public Bina(String address, int numberOfFloors ,String name) {
        super(address);
        this.numberOfFloors = numberOfFloors;
        this.name=name;
    }
    String binaName(){
        return name;
    }
    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.println("Kat Sayısı: " + numberOfFloors);
        System.out.println("Bu bir binadir");
    }
}