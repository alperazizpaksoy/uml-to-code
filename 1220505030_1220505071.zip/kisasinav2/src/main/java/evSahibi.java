public class evSahibi {
    private String name;
    private String address;
    private Bina building;


    public evSahibi(String name, String address, Bina building) {
        this.name = name;
        this.address = address;
        this.building = building;
    }

    public void displayInfo() {
        System.out.println("Name: " + name);
        System.out.println("Address: " + address);
        System.out.println("Building: " + building.binaName());
        System.out.println("Bu bir evsahbidir");
    }
    String evSahibiName(){
        return name;
    }



    void addApartment(Bina building){

    }
}