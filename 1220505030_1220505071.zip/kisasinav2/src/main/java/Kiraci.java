public class Kiraci  {
    private String name;
    private String address;
    private evSahibi evSahibi;


    public Kiraci(String name, String address, evSahibi evSahibi) {
    this.name=name;
    this.address=address;
    this.evSahibi=evSahibi;
    }

    public void displayInfo() {
        System.out.println("Adi : " +name );
        System.out.println("Adres: " + address);
        System.out.println("Ev Sahibi: " + evSahibi.evSahibiName());
        System.out.println("Bu bir kiracidir.");
    }
}
